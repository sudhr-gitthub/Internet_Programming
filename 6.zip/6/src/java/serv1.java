import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class serv1 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Student Registration</title>");
            out.println("</head>");
            out.println("<body>");

            try {

                // Load MySQL driver
                Class.forName("com.mysql.jdbc.Driver");

                // Connect to database
                Connection c = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3307/demo",
                        "root",
                        ""
                );

                // Insert data into student table
                PreparedStatement p = c.prepareStatement(
                        "INSERT INTO ex6 VALUES (?, ?)"
                );

                p.setInt(1, Integer.parseInt(request.getParameter("rollno")));
                p.setString(2, request.getParameter("name"));

                p.executeUpdate();

                out.println("<h2>Student details inserted successfully!</h2>");

                p.close();
                c.close();

            } catch (Exception e) {

                out.println("<h2>Error:</h2>");
                out.println("<p>" + e.getMessage() + "</p>");

            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
