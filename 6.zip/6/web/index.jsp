<!DOCTYPE html>
<html>
<head>
    <title>Student Form</title>
</head>
<body>

    <h1>Student Registration</h1>

    <form action="serv1" method="post">

        <label>Roll Number:</label>
        <input type="number" name="rollno" required>
        <br><br>

        <label>Name:</label>
        <input type="text" name="name" required>
        <br><br>

        <input type="submit" value="Submit">

    </form>

</body>
</html>